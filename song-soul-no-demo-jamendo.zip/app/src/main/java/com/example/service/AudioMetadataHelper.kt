package com.example.service

import android.content.Context
import android.media.MediaMetadataRetriever
import android.net.Uri
import android.provider.OpenableColumns
import com.example.data.model.Track
import java.io.File
import java.io.FileOutputStream
import java.util.UUID

object AudioMetadataHelper {

    fun extractMetadata(context: Context, uri: Uri): Track {
        val retriever = MediaMetadataRetriever()
        var title = ""
        var artist = ""
        var album = ""
        var durationMs = 0L
        var genre = "Soul"
        var artworkUrl: String? = null

        try {
            retriever.setDataSource(context, uri)

            title = retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_TITLE).orEmpty()
            artist = retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_ARTIST).orEmpty()
            album = retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_ALBUM).orEmpty()
            genre = retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_GENRE) ?: "Soul"

            val durationStr = retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION)
            durationMs = durationStr?.toLongOrNull() ?: 0L

            // Extract album artwork if present
            val embeddedArt = retriever.embeddedPicture
            if (embeddedArt != null && embeddedArt.isNotEmpty()) {
                val artFile = File(context.cacheDir, "art_${uri.toString().hashCode()}.jpg")
                FileOutputStream(artFile).use { fos ->
                    fos.write(embeddedArt)
                    fos.flush()
                }
                artworkUrl = artFile.absolutePath
            }
        } catch (_: Exception) {
            // Ignore extraction errors and fallback to URI display name
        } finally {
            try {
                retriever.release()
            } catch (_: Exception) {
            }
        }

        if (title.isBlank()) {
            title = getDisplayName(context, uri) ?: "Local Audio Track"
        }
        if (artist.isBlank()) {
            artist = "Local Artist"
        }
        if (album.isBlank()) {
            album = "My Library"
        }

        return Track(
            id = UUID.randomUUID().toString(),
            title = title,
            artist = artist,
            album = album,
            durationMs = durationMs,
            audioUrl = uri.toString(),
            artworkUrl = artworkUrl,
            genre = genre,
            dateAdded = System.currentTimeMillis(),
            isLocal = true
        )
    }

    private fun getDisplayName(context: Context, uri: Uri): String? {
        if (uri.scheme == "content") {
            try {
                context.contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use { cursor ->
                    if (cursor.moveToFirst()) {
                        val nameIndex = cursor.getColumnIndex(OpenableColumns.DISPLAY_NAME)
                        if (nameIndex != -1) {
                            val full = cursor.getString(nameIndex)
                            return full?.substringBeforeLast('.')
                        }
                    }
                }
            } catch (_: Exception) {
            }
        }
        return uri.lastPathSegment?.substringBeforeLast('.')
    }
}
