package com.example.player

import android.content.Context
import com.example.data.model.Playlist
import com.example.data.model.PlaylistTrackCrossRef
import com.example.data.model.Track
import java.io.File
import java.io.FileOutputStream
import java.nio.ByteBuffer
import java.nio.ByteOrder
import kotlin.math.sin

object SampleAudioProvider {

    /**
     * Synthesizes a pleasant offline melodic ambient soul audio track as a standard 16-bit PCM WAV.
     * Guarantees 100% offline, immediate ExoPlayer playback without external dependencies.
     */
    fun createOfflineSampleWav(context: Context, filename: String, baseFrequency: Double, chordType: Int): File {
        val file = File(context.filesDir, filename)
        if (file.exists() && file.length() > 44) {
            return file
        }

        val sampleRate = 22050
        val durationSeconds = 18
        val totalSamples = sampleRate * durationSeconds
        val numChannels = 2
        val bitsPerSample = 16
        val dataSize = totalSamples * numChannels * (bitsPerSample / 8)

        FileOutputStream(file).use { fos ->
            // Write standard WAV header
            val header = ByteBuffer.allocate(44).order(ByteOrder.LITTLE_ENDIAN)
            header.put("RIFF".toByteArray())
            header.putInt(36 + dataSize)
            header.put("WAVE".toByteArray())
            header.put("fmt ".toByteArray())
            header.putInt(16) // Subchunk1Size for PCM
            header.putShort(1.toShort()) // AudioFormat 1 = PCM
            header.putShort(numChannels.toShort())
            header.putInt(sampleRate)
            header.putInt(sampleRate * numChannels * bitsPerSample / 8) // ByteRate
            header.putShort((numChannels * bitsPerSample / 8).toShort()) // BlockAlign
            header.putShort(bitsPerSample.toShort())
            header.put("data".toByteArray())
            header.putInt(dataSize)
            fos.write(header.array())

            // Generate harmonious soothing chords
            // Chord progressions:
            // 0: Minor 9th soul chord (root, minor 3rd, 5th, minor 7th, 9th)
            // 1: Major 7th warm soul (root, major 3rd, 5th, major 7th)
            // 2: Pentatonic ambient flow
            val noteOffsets = when (chordType) {
                1 -> doubleArrayOf(1.0, 1.2599, 1.4983, 1.8877) // Major 7th
                2 -> doubleArrayOf(1.0, 1.1892, 1.3348, 1.4983, 1.7818) // Pentatonic
                else -> doubleArrayOf(1.0, 1.1892, 1.4983, 1.7818, 2.2449) // Minor 9th
            }

            val buffer = ByteArray(1024)
            var bufferPos = 0

            for (i in 0 until totalSamples) {
                val t = i.toDouble() / sampleRate
                // LFO volume swell for smooth organic soul pulse
                val lfo = 0.65 + 0.35 * sin(2.0 * Math.PI * 0.4 * t)
                // Envelope for fade in and fade out
                val envelope = when {
                    t < 1.0 -> t
                    t > durationSeconds - 2.0 -> (durationSeconds - t) / 2.0
                    else -> 1.0
                }.coerceIn(0.0, 1.0)

                var sampleVal = 0.0
                for ((idx, ratio) in noteOffsets.withIndex()) {
                    val freq = baseFrequency * ratio
                    val vibrato = 1.0 + 0.005 * sin(2.0 * Math.PI * 4.5 * t)
                    val noteWeight = 1.0 / (idx + 1)
                    sampleVal += sin(2.0 * Math.PI * freq * vibrato * t) * noteWeight
                }

                sampleVal *= envelope * lfo * 0.28
                val pcmShort = (sampleVal * 32767.0).coerceIn(-32768.0, 32767.0).toInt().toShort()

                // Left channel
                buffer[bufferPos++] = (pcmShort.toInt() and 0xFF).toByte()
                buffer[bufferPos++] = ((pcmShort.toInt() shr 8) and 0xFF).toByte()

                // Right channel (subtle phase delay for stereo soul warmth)
                val rightShort = ((sampleVal * 0.95) * 32767.0).coerceIn(-32768.0, 32767.0).toInt().toShort()
                buffer[bufferPos++] = (rightShort.toInt() and 0xFF).toByte()
                buffer[bufferPos++] = ((rightShort.toInt() shr 8) and 0xFF).toByte()

                if (bufferPos >= buffer.size) {
                    fos.write(buffer, 0, bufferPos)
                    bufferPos = 0
                }
            }

            if (bufferPos > 0) {
                fos.write(buffer, 0, bufferPos)
            }
            fos.flush()
        }

        return file
    }

    fun getInitialCuratedTracks(context: Context): List<Track> {
        val f1 = createOfflineSampleWav(context, "midnight_soul.wav", 174.61, 0) // F3 minor 9th
        val f2 = createOfflineSampleWav(context, "emerald_echoes.wav", 220.00, 1) // A3 major 7th
        val f3 = createOfflineSampleWav(context, "golden_horizon.wav", 196.00, 2) // G3 pentatonic
        val f4 = createOfflineSampleWav(context, "velvet_groove.wav", 146.83, 0) // D3 minor 9th
        val f5 = createOfflineSampleWav(context, "starlight_serenade.wav", 261.63, 1) // C4 major 7th
        val f6 = createOfflineSampleWav(context, "deep_resonance.wav", 130.81, 2) // C3 deep resonance

        return listOf(
            Track(
                id = "demo_1",
                title = "Midnight Soul",
                artist = "Aura Bloom",
                album = "Cosmic Reverie",
                durationMs = 18000L,
                audioUrl = f1.toURI().toString(),
                artworkUrl = null,
                lyrics = "In the stillness of the night,\nEmerald waves and velvet light.\nFeel the rhythm of your heart,\nWhere the soul and music start.",
                isFavorite = true,
                genre = "Soul",
                dateAdded = System.currentTimeMillis() - 500000,
                isLocal = true
            ),
            Track(
                id = "demo_2",
                title = "Emerald Echoes",
                artist = "Sami Al-Hassan & Ensemble",
                album = "Green Oasis Sessions",
                durationMs = 18000L,
                audioUrl = f2.toURI().toString(),
                artworkUrl = null,
                lyrics = "أصداء الزمرد في المساء،\nتهدي الروح لحن الصفاء.\nنغمات دافئة تسري،\nفي هدوء العمر والرجاء.",
                isFavorite = true,
                genre = "Jazz",
                dateAdded = System.currentTimeMillis() - 400000,
                isLocal = true
            ),
            Track(
                id = "demo_3",
                title = "Golden Horizon",
                artist = "Layla Noor",
                album = "Desert Whispers",
                durationMs = 18000L,
                audioUrl = f3.toURI().toString(),
                artworkUrl = null,
                lyrics = "Golden sands and timeless skies,\nPeaceful dreams as starlight flies.\nBreathe the harmony within,\nWhere new melodies begin.",
                isFavorite = false,
                genre = "Ambient",
                dateAdded = System.currentTimeMillis() - 300000,
                isLocal = true
            ),
            Track(
                id = "demo_4",
                title = "Velvet Groove",
                artist = "The Soul Collective",
                album = "Smooth Nights",
                durationMs = 18000L,
                audioUrl = f4.toURI().toString(),
                artworkUrl = null,
                lyrics = "Late night pulse, velvet bass,\nFloating gently through this space.\nClose your eyes and let it roll,\nPure connection to the soul.",
                isFavorite = false,
                genre = "Lo-Fi",
                dateAdded = System.currentTimeMillis() - 200000,
                isLocal = true
            ),
            Track(
                id = "demo_5",
                title = "Starlight Serenade",
                artist = "Kareem Zein",
                album = "Celestial Strings",
                durationMs = 18000L,
                audioUrl = f5.toURI().toString(),
                artworkUrl = null,
                lyrics = "تحت ضوء النجوم البهية،\nتعزف الروح أنغامًا ندية.\nلحظة تهمس بالسلام،\nوتفيض بالحب والوئام.",
                isFavorite = true,
                genre = "Acoustic",
                dateAdded = System.currentTimeMillis() - 100000,
                isLocal = true
            ),
            Track(
                id = "demo_6",
                title = "Deep Resonance",
                artist = "Maya Waves",
                album = "Subtle Frequencies",
                durationMs = 18000L,
                audioUrl = f6.toURI().toString(),
                artworkUrl = null,
                lyrics = "Subtle bass and grounding tone,\nYou will never walk alone.\nEvery frequency and beat,\nMakes the symphony complete.",
                isFavorite = false,
                genre = "Soul",
                dateAdded = System.currentTimeMillis(),
                isLocal = true
            )
        )
    }

    fun getInitialCuratedPlaylists(): List<Playlist> {
        return listOf(
            Playlist(
                id = "playlist_soul_chill",
                name = "Late Night Soul Chill",
                description = "أنغام هادئة وأوتار دافئة لأوقات الاسترخاء والتأمل",
                coverUrl = null,
                createdAt = System.currentTimeMillis() - 1000000
            ),
            Playlist(
                id = "playlist_acoustic_vibes",
                name = "Acoustic Serenity",
                description = "جلسات صوتية نقية تلامس الروح وتنعش الذهن",
                coverUrl = null,
                createdAt = System.currentTimeMillis() - 500000
            )
        )
    }

    fun getInitialPlaylistTracks(): List<PlaylistTrackCrossRef> {
        return listOf(
            PlaylistTrackCrossRef("playlist_soul_chill", "demo_1", 0),
            PlaylistTrackCrossRef("playlist_soul_chill", "demo_2", 1),
            PlaylistTrackCrossRef("playlist_soul_chill", "demo_4", 2),
            PlaylistTrackCrossRef("playlist_acoustic_vibes", "demo_3", 0),
            PlaylistTrackCrossRef("playlist_acoustic_vibes", "demo_5", 1),
            PlaylistTrackCrossRef("playlist_acoustic_vibes", "demo_6", 2)
        )
    }
}
