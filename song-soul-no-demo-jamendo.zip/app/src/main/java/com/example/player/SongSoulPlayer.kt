package com.example.player

import android.content.Context
import android.net.Uri
import androidx.media3.common.AudioAttributes
import androidx.media3.common.C
import androidx.media3.common.MediaItem
import androidx.media3.common.MediaMetadata
import androidx.media3.common.PlaybackException
import androidx.media3.common.Player
import androidx.media3.exoplayer.ExoPlayer
import com.example.data.model.Track
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch

class SongSoulPlayer(private val context: Context) {

    val exoPlayer: ExoPlayer = ExoPlayer.Builder(context).build().apply {
        setAudioAttributes(
            AudioAttributes.Builder()
                .setContentType(C.AUDIO_CONTENT_TYPE_MUSIC)
                .setUsage(C.USAGE_MEDIA)
                .build(),
            true // handle audio focus
        )
    }

    private val scope = CoroutineScope(Dispatchers.Main)
    private var progressJob: Job? = null

    private val _currentTrack = MutableStateFlow<Track?>(null)
    val currentTrack: StateFlow<Track?> = _currentTrack.asStateFlow()

    private val _isPlaying = MutableStateFlow(false)
    val isPlaying: StateFlow<Boolean> = _isPlaying.asStateFlow()

    private val _currentPositionMs = MutableStateFlow(0L)
    val currentPositionMs: StateFlow<Long> = _currentPositionMs.asStateFlow()

    private val _durationMs = MutableStateFlow(0L)
    val durationMs: StateFlow<Long> = _durationMs.asStateFlow()

    private val _isShuffleEnabled = MutableStateFlow(false)
    val isShuffleEnabled: StateFlow<Boolean> = _isShuffleEnabled.asStateFlow()

    private val _repeatMode = MutableStateFlow(RepeatMode.OFF)
    val repeatMode: StateFlow<RepeatMode> = _repeatMode.asStateFlow()

    private val _queue = MutableStateFlow<List<Track>>(emptyList())
    val queue: StateFlow<List<Track>> = _queue.asStateFlow()

    private val _volume = MutableStateFlow(1.0f)
    val volume: StateFlow<Float> = _volume.asStateFlow()

    private val _errorMessage = MutableStateFlow<String?>(null)
    val errorMessage: StateFlow<String?> = _errorMessage.asStateFlow()

    var onTrackPlayedCallback: ((Track) -> Unit)? = null

    init {
        exoPlayer.addListener(object : Player.Listener {
            override fun onIsPlayingChanged(isPlaying: Boolean) {
                _isPlaying.value = isPlaying
                if (isPlaying) {
                    startProgressTracker()
                } else {
                    stopProgressTracker()
                }
            }

            override fun onPlaybackStateChanged(playbackState: Int) {
                when (playbackState) {
                    Player.STATE_READY -> {
                        val dur = exoPlayer.duration
                        if (dur > 0) {
                            _durationMs.value = dur
                        }
                    }
                    Player.STATE_ENDED -> {
                        handleTrackEnded()
                    }
                    Player.STATE_BUFFERING -> {
                        // Buffering state
                    }
                    Player.STATE_IDLE -> {
                        // Idle state
                    }
                }
            }

            override fun onPlayerError(error: PlaybackException) {
                _errorMessage.value = error.localizedMessage ?: "Playback error"
                _isPlaying.value = false
            }
        })
    }

    private fun startProgressTracker() {
        progressJob?.cancel()
        progressJob = scope.launch {
            while (isActive) {
                if (exoPlayer.isPlaying) {
                    _currentPositionMs.value = exoPlayer.currentPosition.coerceAtLeast(0L)
                    val dur = exoPlayer.duration
                    if (dur > 0) {
                        _durationMs.value = dur
                    }
                }
                delay(300)
            }
        }
    }

    private fun stopProgressTracker() {
        progressJob?.cancel()
        _currentPositionMs.value = exoPlayer.currentPosition.coerceAtLeast(0L)
    }

    fun playTrack(track: Track, newQueue: List<Track> = emptyList()) {
        if (newQueue.isNotEmpty()) {
            _queue.value = newQueue
        } else if (!_queue.value.any { it.id == track.id }) {
            _queue.value = _queue.value + track
        }

        _currentTrack.value = track
        _durationMs.value = if (track.durationMs > 0) track.durationMs else 0L
        _currentPositionMs.value = 0L
        _errorMessage.value = null

        val mediaMetadata = MediaMetadata.Builder()
            .setTitle(track.title)
            .setArtist(track.artist)
            .setAlbumTitle(track.album)
            .apply {
                track.artworkUrl?.let { setArtworkUri(Uri.parse(it)) }
            }
            .build()

        val mediaItem = MediaItem.Builder()
            .setUri(Uri.parse(track.audioUrl))
            .setMediaId(track.id)
            .setMediaMetadata(mediaMetadata)
            .build()

        exoPlayer.setMediaItem(mediaItem)
        exoPlayer.prepare()
        exoPlayer.play()
        _isPlaying.value = true

        onTrackPlayedCallback?.invoke(track)
    }

    fun togglePlayPause() {
        if (exoPlayer.isPlaying) {
            pause()
        } else {
            resume()
        }
    }

    fun pause() {
        exoPlayer.pause()
        _isPlaying.value = false
    }

    fun resume() {
        if (_currentTrack.value != null) {
            if (exoPlayer.playbackState == Player.STATE_ENDED) {
                exoPlayer.seekTo(0)
            }
            exoPlayer.play()
            _isPlaying.value = true
        } else if (_queue.value.isNotEmpty()) {
            playTrack(_queue.value.first())
        }
    }

    fun seekTo(positionMs: Long) {
        val target = positionMs.coerceIn(0L, _durationMs.value.coerceAtLeast(1L))
        exoPlayer.seekTo(target)
        _currentPositionMs.value = target
    }

    fun skipNext() {
        val current = _currentTrack.value ?: return
        val currentQueue = _queue.value
        if (currentQueue.isEmpty()) return

        val currentIndex = currentQueue.indexOfFirst { it.id == current.id }
        if (currentIndex == -1) {
            playTrack(currentQueue.first())
            return
        }

        if (_isShuffleEnabled.value) {
            val remaining = currentQueue.filter { it.id != current.id }
            if (remaining.isNotEmpty()) {
                playTrack(remaining.random())
                return
            }
        }

        val nextIndex = currentIndex + 1
        if (nextIndex < currentQueue.size) {
            playTrack(currentQueue[nextIndex])
        } else if (_repeatMode.value == RepeatMode.ALL) {
            playTrack(currentQueue.first())
        } else {
            // End of queue
            pause()
            seekTo(0)
        }
    }

    fun skipPrevious() {
        if (exoPlayer.currentPosition > 3000L) {
            // If already played more than 3 seconds, restart current track
            seekTo(0)
            return
        }

        val current = _currentTrack.value ?: return
        val currentQueue = _queue.value
        if (currentQueue.isEmpty()) return

        val currentIndex = currentQueue.indexOfFirst { it.id == current.id }
        if (currentIndex > 0) {
            playTrack(currentQueue[currentIndex - 1])
        } else if (_repeatMode.value == RepeatMode.ALL) {
            playTrack(currentQueue.last())
        } else {
            seekTo(0)
        }
    }

    private fun handleTrackEnded() {
        when (_repeatMode.value) {
            RepeatMode.ONE -> {
                exoPlayer.seekTo(0)
                exoPlayer.play()
            }
            RepeatMode.ALL -> {
                skipNext()
            }
            RepeatMode.OFF -> {
                val current = _currentTrack.value
                val currentQueue = _queue.value
                val currentIndex = currentQueue.indexOfFirst { it.id == current?.id }
                if (currentIndex >= 0 && currentIndex < currentQueue.size - 1) {
                    skipNext()
                } else {
                    _isPlaying.value = false
                    _currentPositionMs.value = 0
                }
            }
        }
    }

    fun toggleShuffle() {
        _isShuffleEnabled.value = !_isShuffleEnabled.value
    }

    fun toggleRepeat() {
        _repeatMode.value = when (_repeatMode.value) {
            RepeatMode.OFF -> RepeatMode.ALL
            RepeatMode.ALL -> RepeatMode.ONE
            RepeatMode.ONE -> RepeatMode.OFF
        }
    }

    fun setVolume(vol: Float) {
        val clamped = vol.coerceIn(0f, 1f)
        _volume.value = clamped
        exoPlayer.volume = clamped
    }

    fun addToQueue(track: Track) {
        if (!_queue.value.any { it.id == track.id }) {
            _queue.value = _queue.value + track
        }
    }

    fun removeFromQueue(index: Int) {
        if (index in _queue.value.indices) {
            val list = _queue.value.toMutableList()
            list.removeAt(index)
            _queue.value = list
        }
    }

    fun clearQueue() {
        _queue.value = emptyList()
    }

    fun clearError() {
        _errorMessage.value = null
    }

    fun release() {
        progressJob?.cancel()
        exoPlayer.release()
    }
}
