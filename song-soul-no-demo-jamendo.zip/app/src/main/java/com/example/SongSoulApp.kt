package com.example

import android.app.Application
import com.example.data.repository.MusicRepository
import com.example.player.SongSoulPlayer
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

class SongSoulApp : Application() {

    lateinit var repository: MusicRepository
        private set

    lateinit var player: SongSoulPlayer
        private set

    override fun onCreate() {
        super.onCreate()
        instance = this
        repository = MusicRepository(this)
        player = SongSoulPlayer(this).apply {
            onTrackPlayedCallback = { track ->
                CoroutineScope(Dispatchers.IO).launch {
                    repository.recordPlayed(track.id)
                }
            }
        }
    }

    companion object {
        lateinit var instance: SongSoulApp
            private set
    }
}
