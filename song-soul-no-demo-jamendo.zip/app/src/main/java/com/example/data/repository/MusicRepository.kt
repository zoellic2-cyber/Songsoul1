package com.example.data.repository

import android.content.Context
import com.example.data.database.SongSoulDatabase
import com.example.data.model.PlayHistory
import com.example.data.model.Playlist
import com.example.data.model.PlaylistTrackCrossRef
import com.example.data.model.Track
import com.example.data.model.UserSettings
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.firstOrNull
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

class MusicRepository(private val context: Context) {

    private val db = SongSoulDatabase.getInstance(context)
    private val trackDao = db.trackDao()
    private val playlistDao = db.playlistDao()
    private val settingsDao = db.settingsDao()

    val allTracks: Flow<List<Track>> = trackDao.getAllTracks()
    val favoriteTracks: Flow<List<Track>> = trackDao.getFavoriteTracks()
    val recentlyPlayedTracks: Flow<List<Track>> = trackDao.getRecentlyPlayedTracks(limit = 12)
    val allPlaylists: Flow<List<Playlist>> = playlistDao.getAllPlaylists()
    val userSettings: Flow<UserSettings?> = settingsDao.getSettings()

    init {
        // Remove bundled demo content and initialize only app settings
        CoroutineScope(Dispatchers.IO).launch {
            trackDao.deleteSeededDemoTracks()
            playlistDao.deleteSeededDemoPlaylistLinks()
            playlistDao.deleteSeededDemoPlaylists()
            val settings = settingsDao.getSettings().firstOrNull()
            if (settings == null) {
                seedInitialData()
            }
        }
    }

    suspend fun seedInitialData() = withContext(Dispatchers.IO) {
        settingsDao.insertOrUpdate(
            UserSettings(
                id = 1,
                themeMode = "dark",
                language = "ar",
                audioQuality = "high",
                gaplessPlayback = true,
                normalizeVolume = true
            )
        )
    }

    suspend fun insertTracks(tracks: List<Track>) = withContext(Dispatchers.IO) {
        trackDao.insertTracks(tracks)
    }

    suspend fun insertTrack(track: Track) = withContext(Dispatchers.IO) {
        trackDao.insertTrack(track)
    }

    suspend fun setFavorite(trackId: String, isFavorite: Boolean) = withContext(Dispatchers.IO) {
        trackDao.setFavorite(trackId, isFavorite)
    }

    suspend fun recordPlayed(trackId: String) = withContext(Dispatchers.IO) {
        trackDao.insertHistory(PlayHistory(trackId = trackId, playedAt = System.currentTimeMillis()))
    }

    suspend fun clearHistory() = withContext(Dispatchers.IO) {
        trackDao.clearHistory()
    }

    suspend fun deleteTrack(track: Track) = withContext(Dispatchers.IO) {
        trackDao.deleteTrack(track)
    }

    fun searchTracks(query: String): Flow<List<Track>> {
        return trackDao.searchTracks(query)
    }

    fun getPlaylistTracks(playlistId: String): Flow<List<Track>> {
        return playlistDao.getTracksForPlaylist(playlistId)
    }

    fun getPlaylistById(playlistId: String): Flow<Playlist?> {
        return playlistDao.getPlaylistById(playlistId)
    }

    suspend fun createPlaylist(name: String, description: String = ""): Playlist = withContext(Dispatchers.IO) {
        val newPl = Playlist(
            id = "pl_${System.currentTimeMillis()}",
            name = name,
            description = description,
            coverUrl = null,
            createdAt = System.currentTimeMillis()
        )
        playlistDao.insertPlaylist(newPl)
        newPl
    }

    suspend fun deletePlaylist(playlistId: String) = withContext(Dispatchers.IO) {
        playlistDao.deletePlaylistById(playlistId)
    }

    suspend fun addTrackToPlaylist(playlistId: String, trackId: String) = withContext(Dispatchers.IO) {
        playlistDao.addTrackToPlaylist(PlaylistTrackCrossRef(playlistId, trackId, 0))
    }

    suspend fun removeTrackFromPlaylist(playlistId: String, trackId: String) = withContext(Dispatchers.IO) {
        playlistDao.removeTrackFromPlaylist(playlistId, trackId)
    }

    suspend fun updateSettings(settings: UserSettings) = withContext(Dispatchers.IO) {
        settingsDao.insertOrUpdate(settings)
    }

    suspend fun resetDatabase() = withContext(Dispatchers.IO) {
        trackDao.deleteAllTracks()
        trackDao.clearHistory()
        seedInitialData()
    }
}
