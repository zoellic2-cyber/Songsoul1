package com.example.data.model

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "tracks")
data class Track(
    @PrimaryKey val id: String,
    val title: String,
    val artist: String,
    val album: String = "",
    val durationMs: Long = 0L,
    val audioUrl: String, // Can be content://, file://, or https://
    val artworkUrl: String? = null,
    val lyrics: String? = null,
    val isFavorite: Boolean = false,
    val genre: String = "Soul",
    val dateAdded: Long = System.currentTimeMillis(),
    val isLocal: Boolean = true
)
