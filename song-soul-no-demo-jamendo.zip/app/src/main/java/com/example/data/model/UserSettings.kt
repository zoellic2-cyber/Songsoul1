package com.example.data.model

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "user_settings")
data class UserSettings(
    @PrimaryKey val id: Int = 1,
    val themeMode: String = "dark", // "dark", "light", "system"
    val language: String = "ar", // "ar", "en"
    val audioQuality: String = "high", // "normal", "high", "lossless"
    val gaplessPlayback: Boolean = true,
    val normalizeVolume: Boolean = true
)
