package com.example.data.online

import com.example.data.model.Track
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder

 data class CatalogSearchResult(
    val tracks: List<Track>,
    val providerName: String,
    val isConfigured: Boolean,
    val note: String? = null
)

interface OnlineMusicProvider {
    val providerId: String
    val providerName: String
    val isConfigured: Boolean
    val configurationRequirement: String
    suspend fun searchTracks(query: String): Result<CatalogSearchResult>
    suspend fun getFeaturedTracks(): Result<List<Track>>
}

/**
 * Live search against Jamendo's catalog of independent music.
 * The public test client ID is for development/testing only. Register an app at
 * https://devportal.jamendo.com/ and replace TEST_CLIENT_ID before public release.
 */
class OpenCatalogMusicProvider : OnlineMusicProvider {
    override val providerId: String = "jamendo"
    override val providerName: String = "Jamendo Independent Music"
    override val isConfigured: Boolean = true
    override val configurationRequirement: String = "Uses Jamendo's read API. Replace the test client ID with your own before release."

    private val clientId = TEST_CLIENT_ID

    override suspend fun searchTracks(query: String): Result<CatalogSearchResult> = runCatching {
        val encoded = URLEncoder.encode(query.trim(), "UTF-8")
        val tracks = fetchTracks("search=$encoded&limit=30")
        CatalogSearchResult(
            tracks = tracks,
            providerName = providerName,
            isConfigured = isConfigured,
            note = "Independent music from Jamendo. Availability and usage rights depend on each track's license."
        )
    }

    override suspend fun getFeaturedTracks(): Result<List<Track>> = runCatching {
        fetchTracks("featured=true&limit=30")
    }

    private suspend fun fetchTracks(filters: String): List<Track> = withContext(Dispatchers.IO) {
        val url = URL("https://api.jamendo.com/v3.0/tracks/?client_id=$clientId&format=json&audioformat=mp32&imagesize=300&$filters")
        val connection = (url.openConnection() as HttpURLConnection).apply {
            requestMethod = "GET"
            connectTimeout = 15000
            readTimeout = 20000
            setRequestProperty("Accept", "application/json")
        }
        try {
            val status = connection.responseCode
            val body = (if (status in 200..299) connection.inputStream else connection.errorStream)
                ?.bufferedReader(Charsets.UTF_8)?.use { it.readText() }.orEmpty()
            check(status in 200..299) { "Jamendo request failed (HTTP $status)" }
            val root = JSONObject(body)
            val results = root.optJSONArray("results") ?: return@withContext emptyList()
            buildList {
                for (i in 0 until results.length()) {
                    val item = results.optJSONObject(i) ?: continue
                    val audio = item.optString("audio", "").takeIf { it.startsWith("https://") } ?: continue
                    val id = item.optString("id", "").takeIf { it.isNotBlank() } ?: continue
                    add(
                        Track(
                            id = "jamendo_$id",
                            title = item.optString("name", "Unknown track"),
                            artist = item.optString("artist_name", "Unknown artist"),
                            album = item.optString("album_name", ""),
                            durationMs = item.optLong("duration", 0L) * 1000L,
                            audioUrl = audio,
                            artworkUrl = item.optString("image", "").takeIf { it.startsWith("https://") },
                            lyrics = null,
                            isFavorite = false,
                            genre = "Independent",
                            dateAdded = System.currentTimeMillis(),
                            isLocal = false
                        )
                    )
                }
            }
        } finally {
            connection.disconnect()
        }
    }

    companion object {
        private const val TEST_CLIENT_ID = "709fa152"
    }
}
