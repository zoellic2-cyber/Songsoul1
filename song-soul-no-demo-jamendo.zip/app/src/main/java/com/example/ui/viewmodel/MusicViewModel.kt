package com.example.ui.viewmodel

import android.content.Context
import android.net.Uri
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.SongSoulApp
import com.example.data.model.Playlist
import com.example.data.model.Track
import com.example.data.model.UserSettings
import com.example.data.online.OpenCatalogMusicProvider
import com.example.player.RepeatMode
import com.example.service.AudioMetadataHelper
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

enum class NavigationTab {
    HOME,
    SEARCH,
    LIBRARY,
    SETTINGS
}

enum class SearchFilter {
    ALL,
    SONGS,
    ARTISTS,
    ALBUMS,
    PLAYLISTS
}

enum class LibraryFilter {
    ALL,
    PLAYLISTS,
    FAVORITES,
    ARTISTS,
    HISTORY
}

class MusicViewModel : ViewModel() {

    private val repository = SongSoulApp.instance.repository
    private val player = SongSoulApp.instance.player
    private val onlineProvider = OpenCatalogMusicProvider()

    // Navigation and player modal UI states
    val currentTab = MutableStateFlow(NavigationTab.HOME)
    val isFullPlayerExpanded = MutableStateFlow(false)
    val isQueueSheetVisible = MutableStateFlow(false)
    val isCreatePlaylistDialogVisible = MutableStateFlow(false)
    val trackToAddToPlaylist = MutableStateFlow<Track?>(null)

    // Player state delegated from SongSoulPlayer
    val currentTrack: StateFlow<Track?> = player.currentTrack
    val isPlaying: StateFlow<Boolean> = player.isPlaying
    val currentPositionMs: StateFlow<Long> = player.currentPositionMs
    val durationMs: StateFlow<Long> = player.durationMs
    val isShuffleEnabled: StateFlow<Boolean> = player.isShuffleEnabled
    val repeatMode: StateFlow<RepeatMode> = player.repeatMode
    val queue: StateFlow<List<Track>> = player.queue
    val volume: StateFlow<Float> = player.volume
    val playerError: StateFlow<String?> = player.errorMessage

    // Repository flows
    val allTracks: StateFlow<List<Track>> = repository.allTracks
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val favoriteTracks: StateFlow<List<Track>> = repository.favoriteTracks
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val recentlyPlayed: StateFlow<List<Track>> = repository.recentlyPlayedTracks
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val allPlaylists: StateFlow<List<Playlist>> = repository.allPlaylists
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val userSettings: StateFlow<UserSettings?> = repository.userSettings
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), null)

    // Search
    val searchQuery = MutableStateFlow("")
    val searchFilter = MutableStateFlow(SearchFilter.ALL)
    val onlineSearchResults = MutableStateFlow<List<Track>>(emptyList())
    val isOnlineSearchActive = MutableStateFlow(false)

    val searchResults: StateFlow<List<Track>> = combine(
        allTracks,
        searchQuery,
        onlineSearchResults
    ) { tracks, query, onlineTracks ->
        if (query.isBlank()) {
            emptyList()
        } else {
            val localMatches = tracks.filter {
                it.title.contains(query, ignoreCase = true) ||
                        it.artist.contains(query, ignoreCase = true) ||
                        it.album.contains(query, ignoreCase = true) ||
                        it.genre.contains(query, ignoreCase = true)
            }
            (localMatches + onlineTracks).distinctBy { it.id }
        }
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    // Selected playlist detail state
    val selectedPlaylist = MutableStateFlow<Playlist?>(null)
    private val _selectedPlaylistTracks = MutableStateFlow<List<Track>>(emptyList())
    val selectedPlaylistTracks: StateFlow<List<Track>> = _selectedPlaylistTracks.asStateFlow()

    // Import status message
    private val _importStatusMessage = MutableStateFlow<String?>(null)
    val importStatusMessage: StateFlow<String?> = _importStatusMessage.asStateFlow()

    // Controls
    fun playTrack(track: Track, newQueue: List<Track> = emptyList()) {
        val effectiveQueue = if (newQueue.isNotEmpty()) newQueue else allTracks.value
        player.playTrack(track, effectiveQueue)
    }

    fun togglePlayPause() = player.togglePlayPause()
    fun skipNext() = player.skipNext()
    fun skipPrevious() = player.skipPrevious()
    fun seekTo(positionMs: Long) = player.seekTo(positionMs)
    fun toggleShuffle() = player.toggleShuffle()
    fun toggleRepeat() = player.toggleRepeat()
    fun setVolume(vol: Float) = player.setVolume(vol)
    fun clearPlayerError() = player.clearError()

    fun toggleFavorite(track: Track) {
        viewModelScope.launch {
            repository.setFavorite(track.id, !track.isFavorite)
        }
    }

    fun openPlaylist(playlist: Playlist) {
        selectedPlaylist.value = playlist
        viewModelScope.launch {
            repository.getPlaylistTracks(playlist.id).collect { tracks ->
                _selectedPlaylistTracks.value = tracks
            }
        }
    }

    fun closePlaylist() {
        selectedPlaylist.value = null
        _selectedPlaylistTracks.value = emptyList()
    }

    fun createPlaylist(name: String, description: String = "") {
        if (name.isBlank()) return
        viewModelScope.launch {
            repository.createPlaylist(name.trim(), description.trim())
            isCreatePlaylistDialogVisible.value = false
        }
    }

    fun deletePlaylist(playlistId: String) {
        viewModelScope.launch {
            repository.deletePlaylist(playlistId)
            if (selectedPlaylist.value?.id == playlistId) {
                closePlaylist()
            }
        }
    }

    fun addTrackToPlaylist(playlistId: String, trackId: String) {
        viewModelScope.launch {
            repository.addTrackToPlaylist(playlistId, trackId)
            trackToAddToPlaylist.value = null
        }
    }

    fun removeTrackFromPlaylist(playlistId: String, trackId: String) {
        viewModelScope.launch {
            repository.removeTrackFromPlaylist(playlistId, trackId)
        }
    }

    fun searchOnlineCatalog(query: String) {
        if (query.isBlank()) {
            onlineSearchResults.value = emptyList()
            return
        }
        viewModelScope.launch {
            isOnlineSearchActive.value = true
            val res = onlineProvider.searchTracks(query)
            res.onSuccess { catalog ->
                onlineSearchResults.value = catalog.tracks
            }.onFailure {
                onlineSearchResults.value = emptyList()
            }
            isOnlineSearchActive.value = false
        }
    }

    fun importAudioFiles(context: Context, uris: List<Uri>) {
        if (uris.isEmpty()) return
        viewModelScope.launch {
            val imported = withContext(Dispatchers.IO) {
                uris.mapNotNull { uri ->
                    try {
                        AudioMetadataHelper.extractMetadata(context, uri)
                    } catch (_: Exception) {
                        null
                    }
                }
            }
            if (imported.isNotEmpty()) {
                repository.insertTracks(imported)
                _importStatusMessage.value = "تم استيراد ${imported.size} مقطع صوتي بنجاح"
            } else {
                _importStatusMessage.value = "تعذر قراءة المقاطع الصوتية المحددة"
            }
        }
    }

    fun clearImportStatusMessage() {
        _importStatusMessage.value = null
    }

    fun updateTheme(themeMode: String) {
        viewModelScope.launch {
            val current = userSettings.value ?: UserSettings()
            repository.updateSettings(current.copy(themeMode = themeMode))
        }
    }

    fun updateLanguage(lang: String) {
        viewModelScope.launch {
            val current = userSettings.value ?: UserSettings()
            repository.updateSettings(current.copy(language = lang))
        }
    }

    fun clearHistory() {
        viewModelScope.launch {
            repository.clearHistory()
        }
    }

    fun resetDatabase() {
        viewModelScope.launch {
            repository.resetDatabase()
            _importStatusMessage.value = "تمت إعادة ضبط المكتبة وقوائم التشغيل بنجاح"
        }
    }

    fun removeFromQueue(index: Int) {
        player.removeFromQueue(index)
    }

    fun clearQueue() {
        player.clearQueue()
    }
}
