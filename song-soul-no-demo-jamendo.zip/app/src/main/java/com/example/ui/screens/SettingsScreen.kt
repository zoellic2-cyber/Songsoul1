package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Audiotrack
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.DarkMode
import androidx.compose.material.icons.filled.DeleteSweep
import androidx.compose.material.icons.filled.Equalizer
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Language
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Security
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.UserSettings
import com.example.ui.theme.SoulBlue
import com.example.ui.theme.SoulGreen

@Composable
fun SettingsScreen(
    settings: UserSettings?,
    onThemeChange: (String) -> Unit,
    onLanguageChange: (String) -> Unit,
    onClearHistory: () -> Unit,
    onResetDatabase: () -> Unit,
    modifier: Modifier = Modifier
) {
    val currentTheme = settings?.themeMode ?: "dark"
    val currentLang = settings?.language ?: "ar"

    var showResetDialog by remember { mutableStateOf(false) }
    var showClearHistoryDialog by remember { mutableStateOf(false) }

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .testTag("settings_screen"),
        contentPadding = PaddingValues(start = 16.dp, end = 16.dp, top = 16.dp, bottom = 100.dp)
    ) {
        item {
            Text(
                text = "الإعدادات",
                style = MaterialTheme.typography.titleLarge.copy(
                    fontWeight = FontWeight.ExtraBold,
                    fontSize = 26.sp
                )
            )
            Spacer(modifier = Modifier.height(16.dp))
        }

        // Section: Appearance
        item {
            SettingsSectionHeader(title = "المظهر والتخصيص", icon = Icons.Default.DarkMode)
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text(
                        text = "نمط السمة",
                        style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.SemiBold)
                    )
                    Spacer(modifier = Modifier.height(10.dp))
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        ThemeOptionButton(
                            label = "الوضع الداكن (الافتراضي)",
                            isSelected = currentTheme == "dark",
                            onClick = { onThemeChange("dark") },
                            modifier = Modifier.weight(1f)
                        )
                        ThemeOptionButton(
                            label = "الوضع الفاتح",
                            isSelected = currentTheme == "light",
                            onClick = { onThemeChange("light") },
                            modifier = Modifier.weight(1f)
                        )
                    }
                }
            }
            Spacer(modifier = Modifier.height(18.dp))
        }

        // Section: Language
        item {
            SettingsSectionHeader(title = "اللغة والاتجاه", icon = Icons.Default.Language)
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        ThemeOptionButton(
                            label = "العربية (RTL)",
                            isSelected = currentLang == "ar",
                            onClick = { onLanguageChange("ar") },
                            modifier = Modifier.weight(1f)
                        )
                        ThemeOptionButton(
                            label = "English (LTR)",
                            isSelected = currentLang == "en",
                            onClick = { onLanguageChange("en") },
                            modifier = Modifier.weight(1f)
                        )
                    }
                }
            }
            Spacer(modifier = Modifier.height(18.dp))
        }

        // Section: Audio Quality & Engine
        item {
            SettingsSectionHeader(title = "جودة وتشغيل الصوت", icon = Icons.Default.Equalizer)
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    SettingsRow(
                        title = "جودة البث والتشغيل",
                        subtitle = "فائقة AAC 320 kbps / Lossless PCM"
                    )
                    HorizontalDivider(modifier = Modifier.padding(vertical = 12.dp))
                    SettingsRow(
                        title = "محرك التشغيل الصوتي",
                        subtitle = "AndroidX Media3 ExoPlayer v1.5.1"
                    )
                    HorizontalDivider(modifier = Modifier.padding(vertical = 12.dp))
                    SettingsRow(
                        title = "التشغيل في الخلفية وشاشة القفل",
                        subtitle = "مفعّل عبر MediaSessionService"
                    )
                }
            }
            Spacer(modifier = Modifier.height(18.dp))
        }

        // Section: Data & Library Management
        item {
            SettingsSectionHeader(title = "إدارة البيانات والمكتبة", icon = Icons.Default.DeleteSweep)
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
            ) {
                Column {
                    SettingsActionRow(
                        title = "مسح سجل الاستماع",
                        description = "حذف قائمة المقاطع التي تم الاستماع إليها مؤخراً",
                        icon = Icons.Default.DeleteSweep,
                        onClick = { showClearHistoryDialog = true }
                    )
                    HorizontalDivider()
                    SettingsActionRow(
                        title = "إعادة ضبط المكتبة الأولية",
                        description = "استعادة مقاطع وقوائم Soul الأصلية وإعادة تهيئة قاعدة البيانات",
                        icon = Icons.Default.Refresh,
                        onClick = { showResetDialog = true }
                    )
                }
            }
            Spacer(modifier = Modifier.height(18.dp))
        }

        // Section: Privacy & App Info
        item {
            SettingsSectionHeader(title = "الأمان والخصوصية والمعلومات", icon = Icons.Default.Security)
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text(
                        text = "Song Soul — تطبيق موسيقى أصلي",
                        style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                        color = SoulGreen
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = "الإصدار: 1.0.0 (Native Android Build)\nقاعدة البيانات: Room SQLite مع KSP\nمحرك الصوت: Media3 ExoPlayer\nواجهة المستخدم: Jetpack Compose Material 3",
                        style = MaterialTheme.typography.bodySmall.copy(lineHeight = 20.sp),
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    Spacer(modifier = Modifier.height(10.dp))
                    Text(
                        text = "الخصوصية: جميع الملفات الصوتية المحلية التي تستوردها تظل محفوظة على جهازك بنسبة 100%، ولا يتم إرسال أي ملفات صوتية لأي جهة خارجية.",
                        style = MaterialTheme.typography.bodySmall.copy(fontSize = 11.sp),
                        color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.8f)
                    )
                }
            }
        }
    }

    // Confirmation Dialogs
    if (showResetDialog) {
        AlertDialog(
            onDismissRequest = { showResetDialog = false },
            title = { Text("إعادة ضبط المكتبة") },
            text = { Text("هل أنت متأكد من رغبتك في إعادة ضبط المكتبة واستعادة المقاطع الروحية الأولية؟") },
            confirmButton = {
                TextButton(onClick = {
                    showResetDialog = false
                    onResetDatabase()
                }) {
                    Text("نعم، إعادة ضبط", color = MaterialTheme.colorScheme.error)
                }
            },
            dismissButton = {
                TextButton(onClick = { showResetDialog = false }) {
                    Text("إلغاء")
                }
            }
        )
    }

    if (showClearHistoryDialog) {
        AlertDialog(
            onDismissRequest = { showClearHistoryDialog = false },
            title = { Text("مسح السجل") },
            text = { Text("هل تريد مسح سجل الاستماع بالكامل؟") },
            confirmButton = {
                TextButton(onClick = {
                    showClearHistoryDialog = false
                    onClearHistory()
                }) {
                    Text("مسح", color = MaterialTheme.colorScheme.error)
                }
            },
            dismissButton = {
                TextButton(onClick = { showClearHistoryDialog = false }) {
                    Text("إلغاء")
                }
            }
        )
    }
}

@Composable
fun SettingsSectionHeader(title: String, icon: ImageVector) {
    Row(
        verticalAlignment = Alignment.CenterVertically,
        modifier = Modifier.padding(bottom = 8.dp)
    ) {
        Icon(
            imageVector = icon,
            contentDescription = null,
            tint = SoulGreen,
            modifier = Modifier.size(20.dp)
        )
        Spacer(modifier = Modifier.width(8.dp))
        Text(
            text = title,
            style = MaterialTheme.typography.titleMedium.copy(
                fontWeight = FontWeight.Bold,
                fontSize = 16.sp
            ),
            color = MaterialTheme.colorScheme.onSurface
        )
    }
}

@Composable
fun ThemeOptionButton(
    label: String,
    isSelected: Boolean,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    Box(
        modifier = modifier
            .clip(RoundedCornerShape(12.dp))
            .background(
                if (isSelected) SoulGreen else MaterialTheme.colorScheme.surfaceVariant
            )
            .clickable(onClick = onClick)
            .padding(vertical = 12.dp, horizontal = 8.dp),
        contentAlignment = Alignment.Center
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            if (isSelected) {
                Icon(
                    imageVector = Icons.Default.Check,
                    contentDescription = null,
                    tint = Color.Black,
                    modifier = Modifier.size(16.dp)
                )
                Spacer(modifier = Modifier.width(4.dp))
            }
            Text(
                text = label,
                style = MaterialTheme.typography.labelMedium.copy(
                    fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal
                ),
                color = if (isSelected) Color.Black else MaterialTheme.colorScheme.onSurface
            )
        }
    }
}

@Composable
fun SettingsRow(title: String, subtitle: String) {
    Column {
        Text(
            text = title,
            style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.SemiBold)
        )
        Text(
            text = subtitle,
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )
    }
}

@Composable
fun SettingsActionRow(
    title: String,
    description: String,
    icon: ImageVector,
    onClick: () -> Unit
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clickable(onClick = onClick)
            .padding(16.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Icon(
            imageVector = icon,
            contentDescription = null,
            tint = SoulGreen,
            modifier = Modifier.size(24.dp)
        )
        Spacer(modifier = Modifier.width(14.dp))
        Column(modifier = Modifier.weight(1f)) {
            Text(
                text = title,
                style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.SemiBold)
            )
            Text(
                text = description,
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }
    }
}
