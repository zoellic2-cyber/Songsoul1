package com.example.ui.theme

import android.app.Activity
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.SideEffect
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.platform.LocalView
import androidx.core.view.WindowCompat

private val DarkColorScheme = darkColorScheme(
    primary = SoulGreen,
    onPrimary = SoulDarkBackground,
    primaryContainer = SoulDarkGreen,
    onPrimaryContainer = SoulDarkTextPrimary,
    secondary = SoulBlue,
    onSecondary = SoulDarkBackground,
    secondaryContainer = SoulDarkCardHighlight,
    onSecondaryContainer = SoulDarkTextPrimary,
    background = SoulDarkBackground,
    onBackground = SoulDarkTextPrimary,
    surface = SoulDarkCard,
    onSurface = SoulDarkTextPrimary,
    surfaceVariant = SoulDarkCardHighlight,
    onSurfaceVariant = SoulTextSecondary,
    outline = SoulTextMuted
)

private val LightColorScheme = lightColorScheme(
    primary = SoulDarkGreen,
    onPrimary = SoulLightBackground,
    primaryContainer = SoulGreen,
    onPrimaryContainer = SoulLightBackground,
    secondary = SoulBlue,
    onSecondary = SoulLightBackground,
    secondaryContainer = SoulLightCardHighlight,
    onSecondaryContainer = SoulLightTextPrimary,
    background = SoulLightBackground,
    onBackground = SoulLightTextPrimary,
    surface = SoulLightCard,
    onSurface = SoulLightTextPrimary,
    surfaceVariant = SoulLightCardHighlight,
    onSurfaceVariant = SoulLightTextSecondary,
    outline = SoulTextSecondary
)

@Composable
fun SongSoulTheme(
    darkTheme: Boolean = true, // Default to dark luxury theme as requested
    content: @Composable () -> Unit
) {
    val colorScheme = if (darkTheme) DarkColorScheme else LightColorScheme
    val view = LocalView.current
    if (!view.isInEditMode) {
        SideEffect {
            val window = (view.context as? Activity)?.window ?: return@SideEffect
            window.statusBarColor = colorScheme.background.toArgb()
            window.navigationBarColor = colorScheme.background.toArgb()
            val insetsController = WindowCompat.getInsetsController(window, view)
            insetsController.isAppearanceLightStatusBars = !darkTheme
            insetsController.isAppearanceLightNavigationBars = !darkTheme
        }
    }

    MaterialTheme(
        colorScheme = colorScheme,
        typography = Typography,
        content = content
    )
}
