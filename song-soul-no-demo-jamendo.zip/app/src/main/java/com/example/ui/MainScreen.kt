package com.example.ui

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutVertically
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.LibraryMusic
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.outlined.Home
import androidx.compose.material.icons.outlined.LibraryMusic
import androidx.compose.material.icons.outlined.Search
import androidx.compose.material.icons.outlined.Settings
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.ui.components.AddToPlaylistDialog
import com.example.ui.components.CreatePlaylistDialog
import com.example.ui.components.MiniPlayer
import com.example.ui.screens.FullPlayerScreen
import com.example.ui.screens.HomeScreen
import com.example.ui.screens.LibraryScreen
import com.example.ui.screens.PlaylistDetailScreen
import com.example.ui.screens.QueueBottomSheet
import com.example.ui.screens.SearchScreen
import com.example.ui.screens.SettingsScreen
import com.example.ui.theme.SongSoulTheme
import com.example.ui.theme.SoulGreen
import com.example.ui.viewmodel.MusicViewModel
import com.example.ui.viewmodel.NavigationTab

@Composable
fun MainScreen(viewModel: MusicViewModel) {
    val currentTab by viewModel.currentTab.collectAsStateWithLifecycle()
    val isFullPlayerExpanded by viewModel.isFullPlayerExpanded.collectAsStateWithLifecycle()
    val isQueueSheetVisible by viewModel.isQueueSheetVisible.collectAsStateWithLifecycle()
    val isCreatePlaylistDialogVisible by viewModel.isCreatePlaylistDialogVisible.collectAsStateWithLifecycle()
    val trackToAddToPlaylist by viewModel.trackToAddToPlaylist.collectAsStateWithLifecycle()

    val currentTrack by viewModel.currentTrack.collectAsStateWithLifecycle()
    val isPlaying by viewModel.isPlaying.collectAsStateWithLifecycle()
    val currentPositionMs by viewModel.currentPositionMs.collectAsStateWithLifecycle()
    val durationMs by viewModel.durationMs.collectAsStateWithLifecycle()
    val isShuffleEnabled by viewModel.isShuffleEnabled.collectAsStateWithLifecycle()
    val repeatMode by viewModel.repeatMode.collectAsStateWithLifecycle()
    val queue by viewModel.queue.collectAsStateWithLifecycle()
    val volume by viewModel.volume.collectAsStateWithLifecycle()
    val playerError by viewModel.playerError.collectAsStateWithLifecycle()

    val allTracks by viewModel.allTracks.collectAsStateWithLifecycle()
    val favoriteTracks by viewModel.favoriteTracks.collectAsStateWithLifecycle()
    val recentlyPlayed by viewModel.recentlyPlayed.collectAsStateWithLifecycle()
    val allPlaylists by viewModel.allPlaylists.collectAsStateWithLifecycle()
    val userSettings by viewModel.userSettings.collectAsStateWithLifecycle()

    val searchQuery by viewModel.searchQuery.collectAsStateWithLifecycle()
    val searchResults by viewModel.searchResults.collectAsStateWithLifecycle()
    val isOnlineSearchActive by viewModel.isOnlineSearchActive.collectAsStateWithLifecycle()

    val selectedPlaylist by viewModel.selectedPlaylist.collectAsStateWithLifecycle()
    val selectedPlaylistTracks by viewModel.selectedPlaylistTracks.collectAsStateWithLifecycle()

    val importStatusMessage by viewModel.importStatusMessage.collectAsStateWithLifecycle()
    val snackbarHostState = remember { SnackbarHostState() }

    LaunchedEffect(importStatusMessage) {
        importStatusMessage?.let { msg ->
            snackbarHostState.showSnackbar(msg)
            viewModel.clearImportStatusMessage()
        }
    }

    LaunchedEffect(playerError) {
        playerError?.let { err ->
            snackbarHostState.showSnackbar("تنبيه: $err")
            viewModel.clearPlayerError()
        }
    }

    val isDark = when (userSettings?.themeMode) {
        "light" -> false
        else -> true // default to luxurious dark
    }

    val layoutDirection = if (userSettings?.language == "en") LayoutDirection.Ltr else LayoutDirection.Rtl

    SongSoulTheme(darkTheme = isDark) {
        CompositionLocalProvider(LocalLayoutDirection provides layoutDirection) {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .background(MaterialTheme.colorScheme.background)
            ) {
                Scaffold(
                    modifier = Modifier.fillMaxSize(),
                    snackbarHost = { SnackbarHost(snackbarHostState) },
                    bottomBar = {
                        Column(
                            modifier = Modifier
                                .fillMaxWidth()
                                .navigationBarsPadding()
                        ) {
                            // Mini Player floating right above bottom navigation bar
                            if (currentTrack != null && !isFullPlayerExpanded) {
                                MiniPlayer(
                                    track = currentTrack!!,
                                    isPlaying = isPlaying,
                                    currentPositionMs = currentPositionMs,
                                    durationMs = durationMs,
                                    onTogglePlayPause = { viewModel.togglePlayPause() },
                                    onSkipNext = { viewModel.skipNext() },
                                    onExpandFullPlayer = { viewModel.isFullPlayerExpanded.value = true }
                                )
                            }

                            // Bottom Navigation Bar (Spotify UX: 3-4 primary destinations)
                            NavigationBar(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .height(60.dp),
                                containerColor = MaterialTheme.colorScheme.surface,
                                tonalElevation = 8.dp
                            ) {
                                NavigationBarItem(
                                    selected = currentTab == NavigationTab.HOME && selectedPlaylist == null,
                                    onClick = {
                                        viewModel.closePlaylist()
                                        viewModel.currentTab.value = NavigationTab.HOME
                                    },
                                    icon = {
                                        Icon(
                                            imageVector = if (currentTab == NavigationTab.HOME) Icons.Filled.Home else Icons.Outlined.Home,
                                            contentDescription = "الرئيسية"
                                        )
                                    },
                                    label = { Text("الرئيسية") },
                                    colors = NavigationBarItemDefaults.colors(
                                        selectedIconColor = SoulGreen,
                                        selectedTextColor = SoulGreen,
                                        indicatorColor = SoulGreen.copy(alpha = 0.15f),
                                        unselectedIconColor = MaterialTheme.colorScheme.onSurfaceVariant,
                                        unselectedTextColor = MaterialTheme.colorScheme.onSurfaceVariant
                                    ),
                                    modifier = Modifier.testTag("nav_tab_home")
                                )

                                NavigationBarItem(
                                    selected = currentTab == NavigationTab.SEARCH,
                                    onClick = {
                                        viewModel.closePlaylist()
                                        viewModel.currentTab.value = NavigationTab.SEARCH
                                    },
                                    icon = {
                                        Icon(
                                            imageVector = if (currentTab == NavigationTab.SEARCH) Icons.Filled.Search else Icons.Outlined.Search,
                                            contentDescription = "بحث"
                                        )
                                    },
                                    label = { Text("بحث") },
                                    colors = NavigationBarItemDefaults.colors(
                                        selectedIconColor = SoulGreen,
                                        selectedTextColor = SoulGreen,
                                        indicatorColor = SoulGreen.copy(alpha = 0.15f),
                                        unselectedIconColor = MaterialTheme.colorScheme.onSurfaceVariant,
                                        unselectedTextColor = MaterialTheme.colorScheme.onSurfaceVariant
                                    ),
                                    modifier = Modifier.testTag("nav_tab_search")
                                )

                                NavigationBarItem(
                                    selected = currentTab == NavigationTab.LIBRARY || selectedPlaylist != null,
                                    onClick = {
                                        viewModel.currentTab.value = NavigationTab.LIBRARY
                                    },
                                    icon = {
                                        Icon(
                                            imageVector = if (currentTab == NavigationTab.LIBRARY) Icons.Filled.LibraryMusic else Icons.Outlined.LibraryMusic,
                                            contentDescription = "المكتبة"
                                        )
                                    },
                                    label = { Text("مكتبتك") },
                                    colors = NavigationBarItemDefaults.colors(
                                        selectedIconColor = SoulGreen,
                                        selectedTextColor = SoulGreen,
                                        indicatorColor = SoulGreen.copy(alpha = 0.15f),
                                        unselectedIconColor = MaterialTheme.colorScheme.onSurfaceVariant,
                                        unselectedTextColor = MaterialTheme.colorScheme.onSurfaceVariant
                                    ),
                                    modifier = Modifier.testTag("nav_tab_library")
                                )

                                NavigationBarItem(
                                    selected = currentTab == NavigationTab.SETTINGS,
                                    onClick = {
                                        viewModel.closePlaylist()
                                        viewModel.currentTab.value = NavigationTab.SETTINGS
                                    },
                                    icon = {
                                        Icon(
                                            imageVector = if (currentTab == NavigationTab.SETTINGS) Icons.Filled.Settings else Icons.Outlined.Settings,
                                            contentDescription = "الإعدادات"
                                        )
                                    },
                                    label = { Text("الإعدادات") },
                                    colors = NavigationBarItemDefaults.colors(
                                        selectedIconColor = SoulGreen,
                                        selectedTextColor = SoulGreen,
                                        indicatorColor = SoulGreen.copy(alpha = 0.15f),
                                        unselectedIconColor = MaterialTheme.colorScheme.onSurfaceVariant,
                                        unselectedTextColor = MaterialTheme.colorScheme.onSurfaceVariant
                                    ),
                                    modifier = Modifier.testTag("nav_tab_settings")
                                )
                            }
                        }
                    }
                ) { innerPadding ->
                    Box(
                        modifier = Modifier
                            .fillMaxSize()
                            .padding(innerPadding)
                            .statusBarsPadding()
                    ) {
                        when {
                            selectedPlaylist != null -> {
                                PlaylistDetailScreen(
                                    playlist = selectedPlaylist!!,
                                    tracks = selectedPlaylistTracks,
                                    currentTrack = currentTrack,
                                    isPlaying = isPlaying,
                                    onBack = { viewModel.closePlaylist() },
                                    onTrackClick = { track, list -> viewModel.playTrack(track, list) },
                                    onFavoriteToggle = { viewModel.toggleFavorite(it) },
                                    onAddToPlaylist = { viewModel.trackToAddToPlaylist.value = it },
                                    onRemoveFromPlaylist = { trackId ->
                                        selectedPlaylist?.let { pl ->
                                            viewModel.removeTrackFromPlaylist(pl.id, trackId)
                                        }
                                    },
                                    onShufflePlay = {
                                        if (selectedPlaylistTracks.isNotEmpty()) {
                                            viewModel.playTrack(
                                                selectedPlaylistTracks.random(),
                                                selectedPlaylistTracks.shuffled()
                                            )
                                        }
                                    }
                                )
                            }
                            currentTab == NavigationTab.HOME -> {
                                HomeScreen(
                                    allTracks = allTracks,
                                    recentlyPlayed = recentlyPlayed,
                                    favoriteTracks = favoriteTracks,
                                    playlists = allPlaylists,
                                    currentTrack = currentTrack,
                                    isPlaying = isPlaying,
                                    onTrackClick = { track, list -> viewModel.playTrack(track, list) },
                                    onFavoriteToggle = { viewModel.toggleFavorite(it) },
                                    onAddToPlaylist = { viewModel.trackToAddToPlaylist.value = it },
                                    onOpenPlaylist = { viewModel.openPlaylist(it) }
                                )
                            }
                            currentTab == NavigationTab.SEARCH -> {
                                SearchScreen(
                                    searchQuery = searchQuery,
                                    onSearchQueryChange = { viewModel.searchQuery.value = it },
                                    searchResults = searchResults,
                                    isOnlineSearchActive = isOnlineSearchActive,
                                    onSearchOnline = { viewModel.searchOnlineCatalog(it) },
                                    currentTrack = currentTrack,
                                    isPlaying = isPlaying,
                                    onTrackClick = { track, list -> viewModel.playTrack(track, list) },
                                    onFavoriteToggle = { viewModel.toggleFavorite(it) },
                                    onAddToPlaylist = { viewModel.trackToAddToPlaylist.value = it }
                                )
                            }
                            currentTab == NavigationTab.LIBRARY -> {
                                LibraryScreen(
                                    allTracks = allTracks,
                                    favoriteTracks = favoriteTracks,
                                    playlists = allPlaylists,
                                    recentlyPlayed = recentlyPlayed,
                                    currentTrack = currentTrack,
                                    isPlaying = isPlaying,
                                    onTrackClick = { track, list -> viewModel.playTrack(track, list) },
                                    onFavoriteToggle = { viewModel.toggleFavorite(it) },
                                    onAddToPlaylist = { viewModel.trackToAddToPlaylist.value = it },
                                    onOpenPlaylist = { viewModel.openPlaylist(it) },
                                    onCreatePlaylistClick = { viewModel.isCreatePlaylistDialogVisible.value = true },
                                    onDeletePlaylist = { viewModel.deletePlaylist(it) },
                                    onImportAudioUris = { uris ->
                                        viewModel.importAudioFiles(com.example.SongSoulApp.instance, uris)
                                    }
                                )
                            }
                            currentTab == NavigationTab.SETTINGS -> {
                                SettingsScreen(
                                    settings = userSettings,
                                    onThemeChange = { viewModel.updateTheme(it) },
                                    onLanguageChange = { viewModel.updateLanguage(it) },
                                    onClearHistory = { viewModel.clearHistory() },
                                    onResetDatabase = { viewModel.resetDatabase() }
                                )
                            }
                        }
                    }
                }

                // Full Player Screen (Overlaid with smooth vertical slide animation)
                AnimatedVisibility(
                    visible = isFullPlayerExpanded && currentTrack != null,
                    enter = slideInVertically(initialOffsetY = { it }),
                    exit = slideOutVertically(targetOffsetY = { it })
                ) {
                    if (currentTrack != null) {
                        FullPlayerScreen(
                            track = currentTrack!!,
                            isPlaying = isPlaying,
                            currentPositionMs = currentPositionMs,
                            durationMs = durationMs,
                            isShuffleEnabled = isShuffleEnabled,
                            repeatMode = repeatMode,
                            volume = volume,
                            onClose = { viewModel.isFullPlayerExpanded.value = false },
                            onTogglePlayPause = { viewModel.togglePlayPause() },
                            onSkipNext = { viewModel.skipNext() },
                            onSkipPrevious = { viewModel.skipPrevious() },
                            onSeekTo = { viewModel.seekTo(it) },
                            onToggleShuffle = { viewModel.toggleShuffle() },
                            onToggleRepeat = { viewModel.toggleRepeat() },
                            onVolumeChange = { viewModel.setVolume(it) },
                            onFavoriteToggle = { viewModel.toggleFavorite(currentTrack!!) },
                            onAddToPlaylist = { viewModel.trackToAddToPlaylist.value = currentTrack },
                            onOpenQueue = { viewModel.isQueueSheetVisible.value = true }
                        )
                    }
                }

                // Queue Bottom Sheet
                if (isQueueSheetVisible) {
                    QueueBottomSheet(
                        queue = queue,
                        currentTrack = currentTrack,
                        isPlaying = isPlaying,
                        onDismiss = { viewModel.isQueueSheetVisible.value = false },
                        onTrackSelect = { track ->
                            viewModel.playTrack(track, queue)
                        },
                        onRemoveFromQueue = { index ->
                            viewModel.removeFromQueue(index)
                        },
                        onClearQueue = {
                            viewModel.clearQueue()
                        }
                    )
                }

                // Create Playlist Dialog
                if (isCreatePlaylistDialogVisible) {
                    CreatePlaylistDialog(
                        onDismiss = { viewModel.isCreatePlaylistDialogVisible.value = false },
                        onConfirm = { name, desc ->
                            viewModel.createPlaylist(name, desc)
                        }
                    )
                }

                // Add To Playlist Dialog
                if (trackToAddToPlaylist != null) {
                    AddToPlaylistDialog(
                        track = trackToAddToPlaylist!!,
                        playlists = allPlaylists,
                        onDismiss = { viewModel.trackToAddToPlaylist.value = null },
                        onSelectPlaylist = { pl ->
                            viewModel.addTrackToPlaylist(pl.id, trackToAddToPlaylist!!.id)
                        },
                        onCreateNewPlaylist = {
                            viewModel.isCreatePlaylistDialogVisible.value = true
                        }
                    )
                }
            }
        }
    }
}
