package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Song Soul Official Color Palette
val SoulGreen = Color(0xFF22C55E)
val SoulDarkGreen = Color(0xFF15803D)
val SoulBlue = Color(0xFF3B82F6)

// Dark Theme Colors
val SoulDarkBackground = Color(0xFF0B1120)
val SoulDarkCard = Color(0xFF151E30)
val SoulDarkCardHighlight = Color(0xFF1E293B)
val SoulDarkTextPrimary = Color(0xFFF8FAFC)
val SoulTextSecondary = Color(0xFF94A3B8)
val SoulTextMuted = Color(0xFF64748B)

// Light Theme Colors
val SoulLightBackground = Color(0xFFF8FAFC)
val SoulLightCard = Color(0xFFFFFFFF)
val SoulLightCardHighlight = Color(0xFFF1F5F9)
val SoulLightTextPrimary = Color(0xFF0F172A)
val SoulLightTextSecondary = Color(0xFF475569)

// Accent & Genre Colors
val GenreSoul = Color(0xFF8B5CF6)
val GenreJazz = Color(0xFFEC4899)
val GenreAmbient = Color(0xFF06B6D4)
val GenreLofi = Color(0xFFF59E0B)
val GenrePop = Color(0xFF10B981)
val GenreAcoustic = Color(0xFFE11D48)
val GenreClassical = Color(0xFF6366F1)
val GenreElectronic = Color(0xFF14B8A6)
