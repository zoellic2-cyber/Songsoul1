package com.example

import android.content.Context
import androidx.test.core.app.ApplicationProvider
import com.example.data.model.Playlist
import com.example.data.model.Track
import com.example.ui.components.formatDuration
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [34])
class ExampleRobolectricTest {

    @Test
    fun testAppNameString() {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val appName = context.getString(R.string.app_name)
        assertEquals("Song Soul", appName)
    }

    @Test
    fun testFormatDuration() {
        assertEquals("00:00", formatDuration(0L))
        assertEquals("01:05", formatDuration(65000L))
        assertEquals("03:30", formatDuration(210000L))
    }

    @Test
    fun testTrackModelCreation() {
        val track = Track(
            id = "test_1",
            title = "Midnight Soul",
            artist = "Soul Artist",
            album = "Soul Album",
            durationMs = 180000L,
            audioUrl = "file:///path/to/song.mp3",
            isFavorite = true,
            genre = "Soul"
        )
        assertEquals("Midnight Soul", track.title)
        assertTrue(track.isFavorite)
        assertEquals("Soul", track.genre)
    }

    @Test
    fun testPlaylistModelCreation() {
        val playlist = Playlist(
            id = "pl_1",
            name = "Late Night Chill",
            description = "Soothing soul tunes"
        )
        assertEquals("Late Night Chill", playlist.name)
        assertEquals("Soothing soul tunes", playlist.description)
    }
}
